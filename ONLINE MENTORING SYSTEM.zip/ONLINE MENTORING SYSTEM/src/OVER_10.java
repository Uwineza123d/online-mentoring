/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
class OVER_10 {

    OVER_10(String Username) {
        //throw new UnsupportedOperationException("Not yet implemented");
    }

    void setVisible(boolean b) {
        //throw new UnsupportedOperationException("Not yet implemented");
    }

}
