/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
class LESS_10 {

    LESS_10(String Username) {
       // throw new UnsupportedOperationException("Not yet implemented");
    }

    void setVisible(boolean b) {
       // throw new UnsupportedOperationException("Not yet implemented");
    }

}
